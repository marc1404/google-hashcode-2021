package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
)

func main() {
	inputFileName := os.Args[1]
	inputFilePath := fmt.Sprintf("./input/%s", inputFileName)
	lines := readFile(inputFilePath)
	ingredientToIndex := make(map[string]int)
	ingredientIndex := 0
	pizzas := make([]*Pizza, len(lines) - 1)
	headerLine := lines[0]
	headerParts := strings.Split(headerLine, " ")
	teams := make([]*Team, 0)

	for headerIndex, part := range headerParts[1:] {
		teamCount, _ := strconv.Atoi(part)
		teamSize := headerIndex + 2

		for i := 0; i < teamCount; i++ {
			teams = append(teams, &Team{teamSize, make([]*Pizza, 0), []int{}, false})
		}
	}

	for pizzaId, line := range lines[1:] {
		lineParts := strings.Split(line, " ")
		pizzas[pizzaId] = &Pizza{pizzaId, lineParts[1:], []int{}, false}

		for _, ingredient := range lineParts[1:] {
			_, hasIngredient := ingredientToIndex[ingredient]

			if hasIngredient {
				continue
			}

			ingredientToIndex[ingredient] = ingredientIndex
			ingredientIndex++
		}
	}

	for _, pizza := range pizzas {
		binaryCode := make([]int, len(ingredientToIndex))

		for _, ingredient := range pizza.ingredients {
			ingredientIndex := ingredientToIndex[ingredient]
			binaryCode[ingredientIndex] = 1
		}

		pizza.binaryCode = binaryCode
	}

	for i := 0; i < len(teams); i++ {
		team := teams[len(teams) - 1 - i]
		ok := deliverPizzas(team, pizzas)

		if !ok {
			break
		}
	}

	outputFilePath := fmt.Sprintf("./output/%s", inputFileName)
	outputFile, _ := os.Create(outputFilePath)

	defer outputFile.Close()

	completeTeamsCount := 0

	for _, team := range teams {
		if team.isComplete {
			completeTeamsCount++
		}
	}

	outputFile.WriteString(fmt.Sprintf("%v\n", completeTeamsCount))

	for _, team := range teams {
		if !team.isComplete {
			continue
		}

		outputFile.WriteString(fmt.Sprintf("%v", team.size))

		for _, pizza := range team.pizzas {
			outputFile.WriteString(fmt.Sprintf(" %v", pizza.id))
		}

		outputFile.WriteString("\n")
	}
}

func deliverPizzas(team *Team, pizzas []*Pizza) bool {
	if len(team.pizzas) == 0 {
		ok := deliverFirstPizza(team, pizzas)

		if !ok {
			return false
		}
	}

	for {
		ok := deliverNextPizza(team, pizzas)

		if !ok {
			return false
		}

		if team.isComplete {
			return true
		}
	}
}

func deliverFirstPizza(team *Team, pizzas []*Pizza) bool {
	var bestPizza *Pizza
	maxIngredientCount := 0

	for _, pizza := range pizzas {
		if pizza.isDelivered {
			continue
		}

		if len(pizza.ingredients) > maxIngredientCount {
			bestPizza = pizza
			maxIngredientCount = len(pizza.ingredients)
		}
	}

	if bestPizza == nil {
		return false
	}

	team.pizzas = append(team.pizzas, bestPizza)
	team.binaryCode = bestPizza.binaryCode
	bestPizza.isDelivered = true

	return true
}

func deliverNextPizza(team *Team, pizzas []*Pizza) bool {
	var bestPizza *Pizza
	maxDifference := 0

	for _, pizza := range pizzas {
		if pizza.isDelivered {
			continue
		}

		difference := xorBinary(team.binaryCode, pizza.binaryCode)

		if difference > maxDifference {
			bestPizza = pizza
			maxDifference = difference
		}
	}

	if bestPizza == nil {
		return false
	}

	team.pizzas = append(team.pizzas, bestPizza)
	team.binaryCode = andBinary(team.binaryCode, bestPizza.binaryCode)
	bestPizza.isDelivered = true

	if len(team.pizzas) == team.size {
		team.isComplete = true
	}

	return true
}

func xorBinary(leftBinaryCode, rightBinaryCode []int) int {
	difference := 0

	for i, leftBit := range leftBinaryCode {
		if leftBit != rightBinaryCode[i] {
			difference++
		}
	}

	return difference
}

func andBinary(leftBinaryCode, rightBinaryCode []int) []int {
	result := make([]int, len(leftBinaryCode))

	for i, leftBit := range rightBinaryCode {
		if leftBit == rightBinaryCode[i] {
			result[i] = 1
		}
	}

	return result
}

type Pizza struct {
	id int
	ingredients []string
	binaryCode []int
	isDelivered bool
}

type Team struct {
	size int
	pizzas []*Pizza
	binaryCode []int
	isComplete bool
}

func readFile(filePath string) []string {
	file, err := os.Open(filePath)

	if err != nil {
		log.Fatal(err)
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)
	lines := make([]string, 0)

	for scanner.Scan() {
		line := scanner.Text()

		if line == "" {
			continue
		}

		lines = append(lines, line)
	}

	return lines
}
